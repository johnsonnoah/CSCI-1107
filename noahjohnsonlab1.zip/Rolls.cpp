#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

int roll();
void addTables(int, int []);
void output(int []);

int main() {
	int results[11] = { 0 };		//initalize the result counters to 0
	int dice1, dice2;
	srand(time(NULL));				//seed random generator
	for (int i = 36000; i > 0; i--) {		//loop 36000 times
		dice1 = roll();						//first roll
		dice2 = roll();						//second roll
		addTables((dice1+dice2), results);	//add 1 to the matching counter
	}
	output(results);				//display results
}
/******************************************************************************
roll
Description: returns a random number between 1 and 6
Preconditions: none
Postconditions: random number between 1 and 6 used at function call
******************************************************************************/

int roll() {
	return  1 + (rand() % 6);
}
/******************************************************************************
addTables
Description: increments the total of the digit of the roll's result 
Preconditions: needs the sum of the two dicerolls
Postconditions: 1 is added to the element that matches the sum of the rolls
******************************************************************************/

void addTables(int diceSum, int sums[]) {
	switch (diceSum) {		//match sum to appropriate counter
	case 2: sums[0]++;
		break;
	case 3: sums[1]++;
		break;
	case 4: sums[2]++;
		break;
	case 5: sums[3]++;
		break;
	case 6: sums[4]++;
		break;
	case 7: sums[5]++;
		break;
	case 8: sums[6]++;
		break;
	case 9: sums[7]++;
		break;
	case 10: sums[8]++;
		break;
	case 11: sums[9]++;
		break;
	case 12: sums[10]++;
		break;
	}
}
/******************************************************************************
output
Description: displays the theoretical probability and experimental results of 
the dicerolls
Preconditions: the results array should be filled with the total occurances of 
each possibility
******************************************************************************/
void output(int tab[]) {
	cout<< "  2     3      4      5      6      7      8      9      10      11    12  \n"
		<< "------------------------------------------------------------------------------\n"
		<< "Probability:\n" 
		<< " 1/36  2/36   3/36    4/36   5/36   6/36   5/36   4/36   3/36    2/36   1/36  \n"
		<< "------------------------------------------------------------------------------\n"
		<< "Number of occurances:\n ";
	for (int i = 0; i < 11; i++)	//loop 11 times
		cout << tab[i] << "   ";	//space out each total
	cout << endl;
}